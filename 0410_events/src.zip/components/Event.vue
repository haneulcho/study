<template>
  <div id="contents" :style="`width:${contentsWidth}px`">
    <TabContents />
  </div>
</template>

<script setup>
import TabContents from '@/components/Tab.vue'

defineProps({
  contentsWidth: {
    type: [String, Number]
  }
})
</script>