<template>
  <transition name="loader">
    <PageLoader v-if="isPageLoaded" />
  </transition>
  <Event :contents-width="width" />
</template>

<script setup>
import eventStyle from '@/styles/style.scss'
import { ref, computed, onMounted } from 'vue'

// import 컴포넌트명 from '컴포넌트경로/컴포넌트명.vue'
import PageLoader from '@/components/PageLoader.vue'
import Event from '@/components/Event.vue'

const width = ref(0)
const isPageLoaded = ref(true)

const fixBackgroundBlurry = () => {
  const windowWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth

  width.value = (windowWidth % 2 !== 0) ? windowWidth - 1 : windowWidth
}

const onCreated = () => {
  window.addEventListener('resize', fixBackgroundBlurry)

  setTimeout(() => {
    isPageLoaded.value = false
  }, 500)
}

// 컴포넌트 DOM이 마운트 되면 실행
onMounted(() => {
  fixBackgroundBlurry()
})

// 컴포넌트 setup 코드와 함께 무조건 최초 실행
onCreated()
</script>

<style>
.loader-enter-active,
.loader-leave-active {
  transition: opacity 0.5s ease;
}

.loader-enter-from,
.loader-leave-to {
  opacity: 0;
}
</style>
