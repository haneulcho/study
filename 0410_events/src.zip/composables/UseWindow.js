import { ref, computed } from 'vue'

const UseWindow = () => {

  return {

  }
}

export default UseWindow
