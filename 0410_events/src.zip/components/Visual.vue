<template>
  <div id="visual">
      <div class="inner">
          <h1><a href="/Main/Index">CLOSERS THE CHARACTER</a></h1>
          <h2 class="blind">신규승급 UPDATE</h2>
          <p class="blind">2022. 4. 7</p>
          <h3 class="blind">FETAL CREW 결사대원 바이올렛</h3>
          <p class="btn_movie"><a href="#pop_video"></a></p>
          <span class="rock"></span>
      </div>
  </div>
</template>